export class CreateProgressDto {}
