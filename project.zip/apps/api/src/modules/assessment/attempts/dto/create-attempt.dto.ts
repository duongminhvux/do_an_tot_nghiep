export class CreateAttemptDto {}
