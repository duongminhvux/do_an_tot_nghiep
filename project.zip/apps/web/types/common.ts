// Backend response standard wrapper from TransformInterceptor
export interface ApiResponse<T = any> {
  statusCode: number;
  message?: string;
  data: T;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
}
